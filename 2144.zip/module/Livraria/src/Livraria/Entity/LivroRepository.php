<?php

namespace Livraria\Entity;

use Doctrine\ORM\EntityRepository;

class LivroRepository extends EntityRepository {

}
